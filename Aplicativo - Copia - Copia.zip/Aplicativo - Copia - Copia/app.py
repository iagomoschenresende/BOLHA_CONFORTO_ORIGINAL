from datetime import datetime, timezone
from flask import Flask, render_template, url_for, request, redirect, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin, LoginManager, login_user, login_required, logout_user, current_user
from flask_migrate import Migrate
from sqlalchemy.exc import IntegrityError


app = Flask(__name__)
app.config['SECRET_KEY'] = 'carro123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todos.db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)  # novo campo email
    nome_completo = db.Column(db.String(150), nullable=False)      # novo campo nome completo
    data_nascimento = db.Column(db.Date, nullable=False)           # novo campo data nascimento
    password = db.Column(db.String(150), nullable=False)
    descricao = db.Column(db.Text, nullable=True)

    todos = db.relationship('Todo', backref='owner', lazy=True)
    contatos = db.relationship('ContatoProfissional', backref='usuario', lazy=True)



@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(200), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.now(timezone.utc))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    concluida = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return '<Task %r>' % self.id

class ContatoProfissional(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    telefone = db.Column(db.String(20), nullable=False)
    especializacao = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Agendamento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    contato_id = db.Column(db.Integer, db.ForeignKey('contato_profissional.id'), nullable=False)
    data = db.Column(db.Date, nullable=False)
    horario = db.Column(db.Time, nullable=False)
    motivo = db.Column(db.String(255), nullable=True)

    user = db.relationship('User', backref='agendamentos')
    contato = db.relationship('ContatoProfissional', backref='agendamentos')


class Pessoa(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    # Identificação
    nome = db.Column(db.String(150), nullable=False)
    idade = db.Column(db.Integer)
    sexo = db.Column(db.String(10))
    peso = db.Column(db.Float)
    altura = db.Column(db.Float)


    # Histórico médico
    doencas = db.Column(db.Text)
    cirurgias = db.Column(db.Text)
    internacoes = db.Column(db.Text)
    medicamentos = db.Column(db.Text)

    # Histórico familiar
    doencas_familiares = db.Column(db.Text)


    # Alergias
    alergia_medicamento = db.Column(db.Text)
    alergia_alimento = db.Column(db.Text)
    alergia_outros = db.Column(db.Text)

    # Hábitos de vida
    alimentacao = db.Column(db.Text)
    atividade_fisica = db.Column(db.Text)
    alcool = db.Column(db.Text)
    cigarro = db.Column(db.Text)
    outras_drogas = db.Column(db.Text)

    # Sono
    horas_sono = db.Column(db.Text)
    qualidade_sono = db.Column(db.Text)

    # Aspectos psicossociais
    humor = db.Column(db.Text)


    # Saúde preventiva
    vacinacao = db.Column(db.Text)
    exames_periodicos = db.Column(db.Text)



    # Relacionamento com o usuário
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    usuario = db.relationship('User', backref='pessoas')




@app.route('/', methods=['POST', 'GET'])
@login_required
def index():
    if request.method == 'POST':
        task_content = request.form['content']
        new_task = Todo(content=task_content, owner=current_user)

        try:
            db.session.add(new_task)
            db.session.commit()
            return redirect('/')
        except:
            return 'Erro na adição da task'
        
    else:
        tasks = Todo.query.filter_by(owner=current_user).order_by(Todo.date_created).all()
        return render_template('index.html', tasks=tasks)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            
            return redirect('/')
        flash('Algo deu errado, tente novamente!')  
        return redirect('/login')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        hashed_password = generate_password_hash(request.form['password'], method='pbkdf2:sha256')

        data_nascimento_str = request.form['data_nascimento']
        data_nascimento = datetime.strptime(data_nascimento_str, '%Y-%m-%d').date()

        new_user = User(
            username=request.form['username'],
            email=request.form['email'],
            nome_completo=request.form['nome_completo'],
            data_nascimento=data_nascimento,
            password=hashed_password
            )
        try:
            db.session.add(new_user)
            db.session.commit()
            return redirect('/login')
        except IntegrityError:
            db.session.rollback()
            
            return redirect('/login')
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/login')

@app.route('/delete/<int:id>')
@login_required
def delete(id):
    task_to_delete = Todo.query.get_or_404(id)
    if task_to_delete.owner != current_user:
        return 'Você não tem permissão para excluir esta tarefa.'
    try:
        db.session.delete(task_to_delete)
        db.session.commit()
        return redirect('/')
    except:
        return 'Deu erro para deletar a task'

@app.route('/update/<int:id>', methods=['GET', 'POST'])
@login_required
def update(id):
    task = Todo.query.get_or_404(id)
    if task.owner != current_user:
        return 'Você não tem permissão para editar esta tarefa.'
    
    if request.method == 'POST':
        task.content = request.form['content']
        try:
            db.session.commit()
            return redirect('/')
        except:
            return 'Teve um erro na atualização da task'
    else:
        return render_template('update.html', task=task)

@app.route('/contato')
@login_required
def contato():
    # Lista fixa de profissionais (poderia vir do banco no futuro)
    profissionais = [
        {'nome': 'Dr. João Silva', 'telefone': 'CRM-SP: 123456', 'especializacao': 'Cardiologista'},
        {'nome': 'Dra. Ana Beatriz', 'telefone': 'CRM-RJ: 789012', 'especializacao': 'Dermatologista'},
        {'nome': 'Dr. Lucas Mendes', 'telefone': 'CRM-MG: 345678', 'especializacao': 'Ortopedista'},
        {'nome': 'Dra. Mariana Souza', 'telefone': 'CRP-SP: 123456', 'especializacao': 'Psicóloga'},
        {'nome': 'Dr. Rafael Lima', 'telefone': 'CRN-RJ: 654321', 'especializacao': 'Nutricionista'},
        {'nome': 'Prof. Bruno Martins', 'telefone': 'CREF-RS: 987654', 'especializacao': 'Personal Trainer'},
        {'nome': 'Enf. Juliana Costa', 'telefone': 'COREN-BA: 234567', 'especializacao': 'Enfermeira'},
        {'nome': 'Dr. André Oliveira', 'telefone': 'CRM-SP: 112233', 'especializacao': 'Clínico Geral'}
    ]
    return render_template('contato.html', profissionais=profissionais)


@app.route('/salvar_profissional', methods=['POST'])
@login_required
def salvar_profissional():
    nome = request.form['nome']
    telefone = request.form['telefone']
    especializacao = request.form['especializacao']
    novo_contato = ContatoProfissional(nome=nome, telefone=telefone, especializacao=especializacao, usuario=current_user)
    db.session.add(novo_contato)
    db.session.commit()
    return redirect('/contato')

@app.route('/perfil')
@login_required
def perfil():
    contatos_salvos = ContatoProfissional.query.filter_by(usuario=current_user).all()
    
    return render_template('perfil.html', contatos=contatos_salvos)

@app.route('/remover_contato/<int:id>', methods=['POST'])
@login_required
def remover_contato(id):
    contato = ContatoProfissional.query.get_or_404(id)

    if contato.user_id != current_user.id:
        
        return redirect(url_for('perfil'))

    # Apaga agendamentos associados a esse contato primeiro
    Agendamento.query.filter_by(contato_id=contato.id).delete()

    # Agora apaga o contato
    db.session.delete(contato)
    db.session.commit()
    
    
    return redirect(url_for('perfil'))


@app.route('/atualizar_descricao', methods=['POST'])
@login_required
def atualizar_descricao():
    nova_descricao = request.form.get('descricao')
    current_user.descricao = nova_descricao
    db.session.commit()
    
    return redirect(url_for('perfil'))

@app.route('/concluir/<int:id>', methods=['POST'])
@login_required
def concluir(id):
    task = Todo.query.get_or_404(id)
    if task.owner != current_user:
        return 'Sem permissão'
    task.concluida = not task.concluida
    db.session.commit()
    return redirect('/')

@app.route('/agendar/<int:contato_id>', methods=['GET', 'POST'])
@login_required
def agendar_consulta(contato_id):
    contato = ContatoProfissional.query.get_or_404(contato_id)

    if request.method == 'POST':
        data = request.form['data']
        horario = request.form['horario']
        motivo = request.form['motivo']

        agendamento = Agendamento(
            user_id=current_user.id,
            contato_id=contato_id,
            data=datetime.strptime(data, '%Y-%m-%d').date(),
            horario=datetime.strptime(horario, '%H:%M').time(),
            motivo=motivo
        )
        db.session.add(agendamento)
        db.session.commit()
        
        return redirect(url_for('pagamento', agendamento_id=agendamento.id))

    return render_template('agendamento.html', contato=contato)

@app.route('/meus_agendamentos')
@login_required
def meus_agendamentos():
    agendamentos = Agendamento.query.filter_by(user_id=current_user.id).order_by(Agendamento.data, Agendamento.horario).all()
    return render_template('meus_agendamentos.html', agendamentos=agendamentos)

@app.route('/pagamento/<int:agendamento_id>', methods=['GET', 'POST'])
@login_required
def pagamento(agendamento_id):
    agendamento = Agendamento.query.get_or_404(agendamento_id)

    if agendamento.user_id != current_user.id:
        
        return redirect(url_for('perfil'))

    if request.method == 'POST':
        # Aqui simulamos que o pagamento foi feito
        
        return redirect(url_for('perfil'))

    return render_template('pagamento.html', agendamento=agendamento)

@app.route('/registrar_pessoa', methods=['POST'])
@login_required
def registrar_pessoa():
    nome = request.form.get('nome')
    nova_pessoa = Pessoa(nome=nome, usuario=current_user)
    db.session.add(nova_pessoa)
    db.session.commit()
    return redirect(url_for('perfil'))


@app.route('/pessoa/<int:id>', methods=['GET', 'POST'])
@login_required
def editar_pessoa(id):
    pessoa = Pessoa.query.get_or_404(id)

    if pessoa.user_id != current_user.id:
        
        return redirect(url_for('perfil'))

    if request.method == 'POST':
        # 1. Identificação
        pessoa.nome = request.form['nome']
        pessoa.idade = int(request.form['idade']) if request.form['idade'] else None
        pessoa.sexo = request.form['sexo']
        pessoa.peso = float(request.form['peso']) if request.form['peso'] else None
        pessoa.altura = float(request.form['altura']) if request.form['altura'] else None



        # 4. Histórico médico
        pessoa.doencas = request.form['doencas'] or None
        pessoa.cirurgias = request.form['cirurgias'] or None
        pessoa.internacoes = request.form['internacoes'] or None
        pessoa.medicamentos = request.form['medicamentos'] or None

        # 5. Histórico familiar
        pessoa.doencas_familiares = request.form['doencas_familiares'] or None


        # 6. Alergias
        pessoa.alergia_medicamento = request.form['alergia_medicamento'] or None
        pessoa.alergia_alimento = request.form['alergia_alimento'] or None
        pessoa.alergia_outros = request.form['alergia_outros'] or None

        # 7. Hábitos de vida
        pessoa.alimentacao = request.form['alimentacao'] or None
        pessoa.atividade_fisica = request.form['atividade_fisica'] or None
        pessoa.alcool = request.form['alcool'] or None
        pessoa.cigarro = request.form['cigarro'] or None
        pessoa.outras_drogas = request.form['outras_drogas'] or None

        # 8. Sono
        pessoa.horas_sono = request.form['horas_sono'] or None
        pessoa.qualidade_sono = request.form['qualidade_sono'] or None

        # 9. Aspectos psicossociais
        pessoa.humor = request.form['humor'] or None


        # 10. Saúde preventiva
        pessoa.vacinacao = request.form['vacinacao'] or None
        pessoa.exames_periodicos = request.form['exames_periodicos'] or None



        db.session.commit()
        return redirect(url_for('perfil'))



    return render_template('editar_pessoa.html', pessoa=pessoa)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()

    app.run(debug=True)
